from pathlib import Path
import re,sys
H=Path('app/src/main/assets/index.html');G=Path('app/build.gradle')
if not H.exists(): raise SystemExit('Falta app/src/main/assets/index.html')
h=H.read_text(encoding='utf-8')
# Find menu button and replace all inner markup with an unambiguous water-drop character.
pat=r'(<button\b[^>]*id=["\']menuBtn["\'][^>]*>)(.*?)(</button>)'
m=re.search(pat,h,re.S|re.I)
if not m: raise SystemExit('No se encontro el boton id=menuBtn')
open_tag=m.group(1)
if re.search(r'aria-label=',open_tag,re.I): open_tag=re.sub(r'aria-label=["\'][^"\']*["\']','aria-label="Abrir menú"',open_tag,flags=re.I)
else: open_tag=open_tag[:-1]+' aria-label="Abrir menú">'
replacement=open_tag+'<span id="crnlMenuDrop" aria-hidden="true">💧</span>'+m.group(3)
h=h[:m.start()]+replacement+h[m.end():]
# Append LAST style block to win over all previous hamburger rules.
style='''<style id="crnlMenuDropStyle">#menuBtn.menu-btn,#menuBtn{width:54px!important;height:54px!important;min-width:54px!important;flex:0 0 54px!important;padding:0!important;margin:0!important;border-radius:50%!important;display:flex!important;align-items:center!important;justify-content:center!important;background:rgba(255,255,255,.18)!important;border:1px solid rgba(255,255,255,.38)!important;box-shadow:0 5px 16px rgba(0,0,0,.22)!important;overflow:visible!important}#menuBtn span:not(#crnlMenuDrop){display:none!important}#crnlMenuDrop{display:block!important;width:auto!important;height:auto!important;min-width:0!important;background:transparent!important;border:0!important;margin:0!important;padding:0!important;font-size:36px!important;line-height:1!important;color:#35a7ff!important;font-family:system-ui,"Segoe UI Emoji","Noto Color Emoji",sans-serif!important;transform:none!important;opacity:1!important;visibility:visible!important;text-indent:0!important;letter-spacing:normal!important}@media(max-width:390px){#menuBtn{width:50px!important;height:50px!important;min-width:50px!important;flex-basis:50px!important}#crnlMenuDrop{font-size:33px!important}}</style>'''
h=re.sub(r'<style id="crnlMenuDropStyle">.*?</style>','',h,flags=re.S)
h=h.replace('</head>',style+'</head>',1)
H.write_text(h,encoding='utf-8')
# bump version
if G.exists():
 g=G.read_text();mm=re.search(r'versionCode\s+(\d+)',g);v=int(mm.group(1))+1 if mm else 1;G.write_text(re.sub(r'versionCode\s+\d+',f'versionCode {v}',g,1));print('versionCode',v)
# Hard checks
h=H.read_text(encoding='utf-8'); checks={'menuBtn':bool(re.search(r'id=["\']menuBtn["\']',h)),'drop id':'id="crnlMenuDrop"' in h,'drop glyph':'💧' in h,'last override':'id="crnlMenuDropStyle"' in h,'font size':'font-size:36px!important' in h,'menu logic preserved':('menuPanel' in h or 'id="menu"' in h)}
for k,v in checks.items(): print(('OK   ' if v else 'FAIL ')+k)
if not all(checks.values()): sys.exit(1)
