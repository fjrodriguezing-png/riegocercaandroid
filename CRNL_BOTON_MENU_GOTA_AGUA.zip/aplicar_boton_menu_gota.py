from pathlib import Path
import re,sys
H=Path('app/src/main/assets/index.html');G=Path('app/build.gradle')
if not H.exists():raise SystemExit('Falta index.html')
h=H.read_text(encoding='utf-8')
# Keep menuBtn id and behavior intact. Replace hamburger spans/content by water drop.
# Handles current <button ... id="menuBtn" ...>...</button> regardless of existing hamburger spans.
pat=r'(<button\b[^>]*id="menuBtn"[^>]*>)(.*?)(</button>)'
m=re.search(pat,h,flags=re.S)
if not m:raise SystemExit('No se encontro menuBtn')
open_tag=m.group(1)
# Ensure accessible label remains meaningful.
if 'aria-label=' in open_tag:open_tag=re.sub(r'aria-label="[^"]*"','aria-label="Abrir menú"',open_tag)
else:open_tag=open_tag[:-1]+' aria-label="Abrir menú">'
new=open_tag+'<span class="menu-water-drop" aria-hidden="true">💧</span>'+m.group(3)
h=h[:m.start()]+new+h[m.end():]
# Final CSS override only for menu button appearance. Preserve click/JS and grid panel.
css='''.menu-btn{width:52px!important;height:52px!important;min-width:52px!important;padding:0!important;margin:0!important;border-radius:50%!important;display:flex!important;align-items:center!important;justify-content:center!important;background:rgba(255,255,255,.16)!important;border:1px solid rgba(255,255,255,.32)!important;box-shadow:0 5px 16px rgba(0,0,0,.18)!important}.menu-btn>span:not(.menu-water-drop){display:none!important}.menu-water-drop{display:block!important;width:auto!important;height:auto!important;background:none!important;margin:0!important;font-size:32px!important;line-height:1!important;filter:drop-shadow(0 2px 3px rgba(0,0,0,.28));transform:none!important}@media(max-width:390px){.menu-btn{width:48px!important;height:48px!important;min-width:48px!important;flex-basis:48px!important}.menu-water-drop{font-size:29px!important}}'''
if 'menu-water-drop{' not in h:h=h.replace('</style>',css+'</style>',1)
H.write_text(h,encoding='utf-8')
# bump version only
if G.exists():
 g=G.read_text();mt=re.search(r'versionCode\s+(\d+)',g);v=int(mt.group(1))+1;G.write_text(re.sub(r'versionCode\s+\d+',f'versionCode {v}',g,1));print('versionCode',v)
# hard checks to ensure only button visuals and current app features remain.
h=H.read_text();checks={'menuBtn':'id="menuBtn"' in h,'drop':'menu-water-drop' in h and '💧' in h,'menu panel':('id="menuPanel"' in h or 'id="menu"' in h),'XLSX retained':('receiveXlsxRows' in h or 'xlsxBtn' in h),'radio retained':('mapsRadiusSearch' in h or 'id="search"' in h),'WhatsApp retained':('crnlFWa' in h or 'elementActionWhatsApp' in h or 'id="aWa"' in h),'Earth retained':'earthMenu' in h}
for k,v in checks.items():print(('OK   ' if v else 'FAIL ')+k)
if not all(checks.values()):sys.exit(1)
